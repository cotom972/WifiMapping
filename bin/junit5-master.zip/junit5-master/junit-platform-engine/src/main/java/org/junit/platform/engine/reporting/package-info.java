/**
 * Classes used by test engines to report additional data to execution
 * listeners.
 */

package org.junit.platform.engine.reporting;
