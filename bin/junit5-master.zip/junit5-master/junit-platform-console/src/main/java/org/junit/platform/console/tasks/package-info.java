/**
 * Internal execution tasks for JUnit's console launcher.
 */

package org.junit.platform.console.tasks;
