/**
 * Configuration options for JUnit's console launcher.
 */

package org.junit.platform.console.options;
