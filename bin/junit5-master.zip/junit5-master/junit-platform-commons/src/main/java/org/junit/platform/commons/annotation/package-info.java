/**
 * Common annotations for the JUnit Platform.
 */

package org.junit.platform.commons.annotation;
